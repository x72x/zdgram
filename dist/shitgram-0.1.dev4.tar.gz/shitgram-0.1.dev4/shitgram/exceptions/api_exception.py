
class ApiException(Exception):
    pass