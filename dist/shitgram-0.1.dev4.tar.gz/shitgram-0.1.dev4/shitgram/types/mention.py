

class Mention:
    markdown: str
    html: str