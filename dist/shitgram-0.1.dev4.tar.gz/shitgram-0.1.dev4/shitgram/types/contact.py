
class Contact:
    phone_number: str
    first_name: str
    last_name: str
    user_id: int
    vcard: int