
class Dice:
    emoji: str
    value: int