
class UserShared:
    user_id: int
    request_id: int