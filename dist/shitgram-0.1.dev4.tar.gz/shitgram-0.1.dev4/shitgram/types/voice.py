

class Voice:
    file_id: str
    file_unique_id: str
    duration: int
    mime_type: str
    file_size: int