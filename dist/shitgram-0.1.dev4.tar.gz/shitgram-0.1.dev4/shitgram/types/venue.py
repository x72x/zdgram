import shitgram

class Venue:
    location: "shitgram.types.Location"
    title: str
    address: str
    foursquare_id: str
    foursquare_type: str
    google_place_id: str
    google_place_type: str