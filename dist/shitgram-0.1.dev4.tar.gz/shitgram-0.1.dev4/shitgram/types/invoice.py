
class Invoice:
    title: str
    description: str
    start_parameter: str
    currency: str
    total_amount: int