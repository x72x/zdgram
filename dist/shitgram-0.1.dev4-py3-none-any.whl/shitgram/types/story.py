
class Story:
    pass