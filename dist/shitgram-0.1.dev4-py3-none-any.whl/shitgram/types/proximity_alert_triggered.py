import shitgram

class ProximityAlertTriggered:
    traveler: "shitgram.types.User"
    watcher: "shitgram.types.User"
    distance: int