
class ChatShared:
    chat_id: int
    request_id: int