
class MessageAutoDeleteTimerChanged:
    message_auto_delete_time: int