import shitgram

class ChatLocation:
    location: "shitgram.types.Location"
    address: str