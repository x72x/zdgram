
class WriteAccessAllowed:
    from_request: bool
    web_app_name: str
    from_attachment_menu: bool